package com.example.hunter

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var scanBtn: Button
    private lateinit var recyclerView: RecyclerView
    private val appList = mutableListOf<AppInfo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scanBtn = findViewById(R.id.scanBtn)
        recyclerView = findViewById(R.id.recyclerView)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = AppAdapter(appList)

        scanBtn.setOnClickListener { scanApps() }
    }

    private fun scanApps() {
        appList.clear()
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        val highRisk = listOf(
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.READ_SMS"
        )

        val mediumRisk = listOf(
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.READ_CONTACTS"
        )

        for (app in apps) {
            try {
                val packageInfo = pm.getPackageInfo(app.packageName, PackageManager.GET_PERMISSIONS)
                val permissions = packageInfo.requestedPermissions

                if (!permissions.isNullOrEmpty()) {
                    for (perm in permissions) {
                        when {
                            highRisk.contains(perm) -> {
                                appList.add(
                                    AppInfo(
                                        app.loadLabel(pm).toString(),
                                        "HIGH 🔴",
                                        perm,
                                        app.loadIcon(pm)
                                    )
                                )
                                break
                            }
                            mediumRisk.contains(perm) -> {
                                appList.add(
                                    AppInfo(
                                        app.loadLabel(pm).toString(),
                                        "MEDIUM 🟡",
                                        perm,
                                        app.loadIcon(pm)
                                    )
                                )
                                break
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        recyclerView.adapter?.notifyDataSetChanged()
    }
}