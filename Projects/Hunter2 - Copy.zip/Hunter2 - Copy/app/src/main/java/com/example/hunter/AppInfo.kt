package com.example.hunter

import android.graphics.drawable.Drawable

data class AppInfo(
    val name: String,
    val riskLevel: String,
    val permission: String,
    val icon: Drawable
)