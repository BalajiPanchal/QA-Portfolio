
import { test, expect } from '@playwright/test';

test('TodoMVC App Automation Flow', async ({ page }) => {

  await page.goto('https://demo.playwright.dev/todomvc/#/');


  const tasks = ['Buy milk', 'Pay bills', 'Call mom'];
  for (const task of tasks) {
    await page.locator('.new-todo').fill(task);
    await page.keyboard.press('Enter');
  
  }
  const todoItems = page.locator('.todo-list li');
  await expect(todoItems).toHaveCount(3);

  //  Mark “Pay bills” as completed
  await page.locator("//label[text()='Pay bills']/../input[@class='toggle']").check();

  //  Verify one completed item
  const completedItems = page.locator('.todo-list li.completed');
  await expect(completedItems).toHaveCount(1);

  //  Delete call mom
  const callMom = page.locator("//label[text()='Call mom']/..");
  await callMom.hover();
  await callMom.locator('.destroy').click();

  //  Verify “Call mom” is removed
  const remainingTasks = await page.locator('.todo-list li label').allTextContents();
  expect(remainingTasks).not.toContain('Call mom');

  //Take screenshot
  await page.screenshot({ path: 'todo_result.png' });

  console.log('🎯 All test steps passed successfully! Screenshot saved as todo_result.png');
});





